const User = require('../models/User');

// ── Obtener lista de amigos ───────────────────────────────────────────────────
const getFriends = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id).populate('friends', 'name email profilePic');
    if (!user) return res.status(404).json({ message: 'Usuario no encontrado.' });
    res.json(user.friends);
  } catch (err) {
    next(err);
  }
};

// ── Agregar amigo ─────────────────────────────────────────────────────────────
const addFriend = async (req, res, next) => {
  try {
    const { friendId } = req.body;
    if (friendId === req.user.id) {
      return res.status(400).json({ message: 'No puedes agregarte a ti mismo.' });
    }

    const [user, friend] = await Promise.all([
      User.findById(req.user.id),
      User.findById(friendId),
    ]);

    if (!friend) return res.status(404).json({ message: 'Usuario no encontrado.' });
    if (user.friends.includes(friendId)) {
      return res.status(400).json({ message: 'Ya son amigos.' });
    }

    // Relación bidireccional
    user.friends.push(friendId);
    friend.friends.push(req.user.id);
    await Promise.all([user.save(), friend.save()]);

    res.json({ message: `${friend.name} agregado como amigo.` });
  } catch (err) {
    next(err);
  }
};

// ── Eliminar amigo ────────────────────────────────────────────────────────────
const removeFriend = async (req, res, next) => {
  try {
    const { friendId } = req.params;

    const [user, friend] = await Promise.all([
      User.findById(req.user.id),
      User.findById(friendId),
    ]);

    if (!friend) return res.status(404).json({ message: 'Usuario no encontrado.' });

    user.friends.pull(friendId);
    friend.friends.pull(req.user.id);
    await Promise.all([user.save(), friend.save()]);

    res.json({ message: 'Amigo eliminado.' });
  } catch (err) {
    next(err);
  }
};

module.exports = { getFriends, addFriend, removeFriend };
