const User = require('../models/User');

// ── Obtener perfil del usuario autenticado ────────────────────────────────────
const getProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id).populate('friends', 'name email profilePic');
    if (!user) return res.status(404).json({ message: 'Usuario no encontrado.' });
    res.json(user);
  } catch (err) {
    next(err);
  }
};

// ── Actualizar perfil ─────────────────────────────────────────────────────────
const updateProfile = async (req, res, next) => {
  try {
    const { name, email, password, profilePic } = req.body;
    const user = await User.findById(req.user.id).select('+password');
    if (!user) return res.status(404).json({ message: 'Usuario no encontrado.' });

    if (name) user.name = name;
    if (email) user.email = email;
    if (profilePic) user.profilePic = profilePic;
    if (password) user.password = password; // el pre-save hook lo hashea

    await user.save();
    res.json({ message: 'Perfil actualizado.', user: { id: user._id, name: user.name, email: user.email, profilePic: user.profilePic } });
  } catch (err) {
    next(err);
  }
};

// ── Buscar usuarios por nombre ────────────────────────────────────────────────
const searchUsers = async (req, res, next) => {
  try {
    const { q } = req.query;
    if (!q) return res.json([]);

    const users = await User.find({
      name: { $regex: q, $options: 'i' },
      _id: { $ne: req.user.id },
    }).select('name email profilePic');

    res.json(users);
  } catch (err) {
    next(err);
  }
};

module.exports = { getProfile, updateProfile, searchUsers };
