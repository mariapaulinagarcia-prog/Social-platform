const Post = require('../models/Post');
const { addToFeed, removeFromFeed, loadFeed } = require('../utils/postFeed');
const { recordAction }                        = require('../utils/activityStack');
const { pushNotification }                    = require('../utils/notificationQueue');

// ── Obtener todos los posts (feed) ────────────────────────────────────────────
const getPosts = async (req, res, next) => {
  try {
    const posts = await Post.find()
      .populate('user', 'name profilePic')
      .populate('comments.user', 'name profilePic')
      .sort({ createdAt: -1 });

    // Cargar en la Lista Enlazada para el feed en memoria
    loadFeed(posts);

    res.json(posts);
  } catch (err) {
    next(err);
  }
};

// ── Crear post ────────────────────────────────────────────────────────────────
const createPost = async (req, res, next) => {
  try {
    const { content } = req.body;
    const post = await Post.create({ user: req.user.id, content });
    await post.populate('user', 'name profilePic');

    // Agregar al inicio de la Lista Enlazada
    addToFeed(post);

    // Registrar en la Pila de actividad
    recordAction(req.user.id, `Publicó: "${content.substring(0, 40)}"`);

    res.status(201).json(post);
  } catch (err) {
    next(err);
  }
};

// ── Eliminar post ─────────────────────────────────────────────────────────────
const deletePost = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post no encontrado.' });
    if (post.user.toString() !== req.user.id) {
      return res.status(403).json({ message: 'No tienes permiso para eliminar este post.' });
    }
    await post.deleteOne();

    // Eliminar de la Lista Enlazada
    removeFromFeed(req.params.id);

    // Registrar en la Pila
    recordAction(req.user.id, 'Eliminó un post');

    res.json({ message: 'Post eliminado.' });
  } catch (err) {
    next(err);
  }
};

// ── Like / Unlike ─────────────────────────────────────────────────────────────
const toggleLike = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id).populate('user', 'name');
    if (!post) return res.status(404).json({ message: 'Post no encontrado.' });

    const userId      = req.user.id;
    const alreadyLiked = post.likes.includes(userId);

    if (alreadyLiked) {
      post.likes.pull(userId);
    } else {
      post.likes.push(userId);
      // Notificar al autor via Cola (si no es el mismo usuario)
      if (post.user._id.toString() !== userId) {
        pushNotification(post.user._id, {
          type:    'like',
          message: `${req.user.name} le dio like a tu publicación`,
          postId:  post._id,
        });
      }
    }

    await post.save();

    // Registrar en la Pila
    recordAction(userId, `${alreadyLiked ? 'Quitó like' : 'Dio like'} a un post`);

    res.json({ likes: post.likes.length, liked: !alreadyLiked });
  } catch (err) {
    next(err);
  }
};

// ── Agregar comentario ────────────────────────────────────────────────────────
const addComment = async (req, res, next) => {
  try {
    const { text } = req.body;
    const post = await Post.findById(req.params.id).populate('user', 'name');
    if (!post) return res.status(404).json({ message: 'Post no encontrado.' });

    post.comments.push({ user: req.user.id, text });
    await post.save();
    await post.populate('comments.user', 'name profilePic');

    // Notificar al autor via Cola
    if (post.user._id.toString() !== req.user.id) {
      pushNotification(post.user._id, {
        type:    'comment',
        message: `${req.user.name} comentó en tu publicación`,
        postId:  post._id,
      });
    }

    // Registrar en la Pila
    recordAction(req.user.id, 'Comentó en un post');

    const newComment = post.comments[post.comments.length - 1];
    res.status(201).json(newComment);
  } catch (err) {
    next(err);
  }
};

module.exports = { getPosts, createPost, deletePost, toggleLike, addComment };
