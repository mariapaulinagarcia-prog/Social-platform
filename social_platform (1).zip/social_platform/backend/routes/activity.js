const express = require('express');
const router  = express.Router();
const auth    = require('../middlewares/auth');
const { flushNotifications, pendingCount } = require('../utils/notificationQueue');
const { getHistory, getLastAction }        = require('../utils/activityStack');

// GET /api/activity/notifications — obtener y vaciar notificaciones (Cola)
router.get('/notifications', auth, (req, res) => {
  const notifications = flushNotifications(req.user.id);
  res.json({ count: notifications.length, notifications });
});

// GET /api/activity/notifications/count — cuántas notificaciones pendientes
router.get('/notifications/count', auth, (req, res) => {
  res.json({ count: pendingCount(req.user.id) });
});

// GET /api/activity/history — historial de acciones del usuario (Pila)
router.get('/history', auth, (req, res) => {
  res.json({ history: getHistory(req.user.id) });
});

// GET /api/activity/last — última acción (cima de la Pila)
router.get('/last', auth, (req, res) => {
  res.json({ last: getLastAction(req.user.id) });
});

module.exports = router;
