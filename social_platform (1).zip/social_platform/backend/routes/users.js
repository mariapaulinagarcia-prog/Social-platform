const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const { getProfile, updateProfile, searchUsers } = require('../controllers/userController');

// Todas las rutas requieren autenticación
router.use(auth);

// GET  /api/users/me       → perfil del usuario autenticado
router.get('/me', getProfile);

// PUT  /api/users/me       → actualizar perfil
router.put('/me', updateProfile);

// GET  /api/users/search?q=nombre
router.get('/search', searchUsers);

module.exports = router;
