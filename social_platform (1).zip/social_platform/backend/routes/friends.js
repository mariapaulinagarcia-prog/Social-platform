const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const { getFriends, addFriend, removeFriend } = require('../controllers/friendController');

router.use(auth);

// GET    /api/friends          → lista de amigos
router.get('/', getFriends);

// POST   /api/friends          → agregar amigo { friendId }
router.post('/', addFriend);

// DELETE /api/friends/:friendId → eliminar amigo
router.delete('/:friendId', removeFriend);

module.exports = router;
