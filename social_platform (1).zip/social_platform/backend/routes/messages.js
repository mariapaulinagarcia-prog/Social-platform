const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const Message = require('../models/Message');

// GET /api/messages/:friendId — historial de chat con un amigo
router.get('/:friendId', auth, async (req, res, next) => {
  try {
    const roomId = [req.user.id, req.params.friendId].sort().join('_');
    const messages = await Message.find({ roomId })
      .populate('from', 'name')
      .sort({ createdAt: 1 })
      .limit(100);
    res.json(messages);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
