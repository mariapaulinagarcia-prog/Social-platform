const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const { getPosts, createPost, deletePost, toggleLike, addComment } = require('../controllers/postController');

router.use(auth);

// GET    /api/posts          → feed de publicaciones
router.get('/', getPosts);

// POST   /api/posts          → crear publicación
router.post('/', createPost);

// DELETE /api/posts/:id      → eliminar publicación propia
router.delete('/:id', deletePost);

// POST   /api/posts/:id/like → dar/quitar like
router.post('/:id/like', toggleLike);

// POST   /api/posts/:id/comments → agregar comentario
router.post('/:id/comments', addComment);

module.exports = router;
