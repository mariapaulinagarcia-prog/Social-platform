/**
 * Middleware global de manejo de errores.
 * Captura cualquier error lanzado con next(err) en los controladores.
 */
const errorHandler = (err, req, res, next) => {
  console.error('❌ Error:', err.message);

  const statusCode = err.statusCode || 500;
  const message = err.message || 'Error interno del servidor';

  // Errores de validación de Mongoose
  if (err.name === 'ValidationError') {
    const errors = Object.values(err.errors).map((e) => e.message);
    return res.status(400).json({ message: 'Error de validación', errors });
  }

  // Clave duplicada en MongoDB (ej: email único)
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue)[0];
    return res.status(400).json({ message: `El campo '${field}' ya está en uso.` });
  }

  res.status(statusCode).json({ message });
};

module.exports = errorHandler;
