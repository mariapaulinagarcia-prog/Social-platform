/**
 * seed.js — Pobla MongoDB con los datos iniciales de los archivos JSON
 * Uso: node backend/scripts/seed.js
 */
require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Post = require('../models/Post');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/red_social';

const usersData = [
  { name: 'Juan Pérez',   email: 'juan@example.com',   password: '123456' },
  { name: 'Ana Gómez',    email: 'ana@example.com',    password: '123456' },
  { name: 'Carlos Ruiz',  email: 'carlos@example.com', password: '123456' },
];

async function seed() {
  await mongoose.connect(MONGO_URI);
  console.log('✅ Conectado a MongoDB');

  // Limpiar colecciones
  await User.deleteMany({});
  await Post.deleteMany({});

  // Crear usuarios (el pre-save hook hashea las contraseñas)
  const users = await User.insertMany(
    await Promise.all(
      usersData.map(async (u) => ({
        ...u,
        password: await bcrypt.hash(u.password, 10),
      }))
    )
  );

  const [juan, ana, carlos] = users;

  // Relaciones de amistad
  juan.friends = [ana._id, carlos._id];
  ana.friends  = [juan._id];
  carlos.friends = [juan._id];
  await Promise.all([juan.save(), ana.save(), carlos.save()]);

  // Posts iniciales
  await Post.create([
    {
      user: juan._id,
      content: 'Hoy fue un gran día trabajando en mi proyecto 🚀',
      likes: [ana._id],
      comments: [{ user: ana._id, text: '¡Excelente trabajo! Sigue así 💪' }],
    },
    {
      user: ana._id,
      content: '¿Alguien más emocionado con el nuevo semestre? 📚',
      likes: [juan._id, carlos._id],
      comments: [],
    },
  ]);

  console.log('🌱 Seed completado exitosamente');
  console.log('   Usuarios creados:', users.map(u => u.email).join(', '));
  await mongoose.disconnect();
}

seed().catch((err) => {
  console.error('❌ Error en seed:', err);
  process.exit(1);
});
