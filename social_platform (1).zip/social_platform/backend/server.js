const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');
require('dotenv').config();

const authRoutes     = require('./routes/auth');
const userRoutes     = require('./routes/users');
const postRoutes     = require('./routes/posts');
const friendRoutes   = require('./routes/friends');
const messageRoutes  = require('./routes/messages');
const activityRoutes = require('./routes/activity');
const errorHandler = require('./middlewares/errorHandler');
const initSockets = require('./sockets/chat');

const app = express();
const server = http.createServer(app);

// ── Middlewares globales ──────────────────────────────────────────────────────
app.use(cors({ origin: process.env.CLIENT_ORIGIN || '*', credentials: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../static')));

// ── Rutas ─────────────────────────────────────────────────────────────────────
app.use('/api/auth',      authRoutes);
app.use('/api/users',     userRoutes);
app.use('/api/posts',     postRoutes);
app.use('/api/friends',   friendRoutes);
app.use('/api/messages',  messageRoutes);
app.use('/api/activity',  activityRoutes);

// ── Manejo de errores ─────────────────────────────────────────────────────────
app.use(errorHandler);

// ── Sockets ───────────────────────────────────────────────────────────────────
initSockets(server);

// ── Conexión a MongoDB y arranque ─────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/red_social';

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log('✅ Conectado a MongoDB:', MONGO_URI);
    server.listen(PORT, () => console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('❌ Error al conectar a MongoDB:', err.message);
    process.exit(1);
  });
