const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema(
  {
    from: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    to:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    message: { type: String, required: true, trim: true },
    roomId: { type: String, required: true, index: true }, // IDs ordenados: "id1_id2"
  },
  { timestamps: true }
);

module.exports = mongoose.model('Message', messageSchema);
