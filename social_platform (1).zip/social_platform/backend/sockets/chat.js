const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');
const Message = require('../models/Message');

/**
 * Inicializa los sockets de chat en tiempo real.
 * Guarda cada mensaje en MongoDB para historial persistente.
 */
const initSockets = (httpServer) => {
  const io = new Server(httpServer, {
    cors: { origin: '*', methods: ['GET', 'POST'] },
  });

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('Token no proporcionado'));
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret_key');
      socket.user = decoded;
      next();
    } catch {
      next(new Error('Token inválido'));
    }
  });

  const onlineUsers = new Map();

  io.on('connection', (socket) => {
    const userId = socket.user.id;
    onlineUsers.set(userId.toString(), socket.id);
    console.log(`🟢 Usuario conectado: ${socket.user.name}`);
    io.emit('online_users', Array.from(onlineUsers.keys()));

    // Unirse a sala privada
    socket.on('join_room', ({ friendId }) => {
      const roomId = [userId, friendId].sort().join('_');
      socket.join(roomId);
    });

    // Enviar y guardar mensaje
    socket.on('send_message', async ({ friendId, message }) => {
      const roomId = [userId, friendId].sort().join('_');

      // Guardar en MongoDB
      try {
        await Message.create({ from: userId, to: friendId, message, roomId });
      } catch (e) {
        console.error('Error guardando mensaje:', e.message);
      }

      const payload = {
        from: { id: userId, name: socket.user.name },
        message,
        timestamp: new Date().toISOString(),
      };
      io.to(roomId).emit('receive_message', payload);
    });

    socket.on('disconnect', () => {
      onlineUsers.delete(userId.toString());
      io.emit('online_users', Array.from(onlineUsers.keys()));
      console.log(`🔴 Usuario desconectado: ${socket.user.name}`);
    });
  });

  return io;
};

module.exports = initSockets;
