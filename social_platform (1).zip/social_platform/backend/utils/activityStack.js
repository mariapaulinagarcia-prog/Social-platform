/**
 * activityStack.js
 * Historial de acciones del usuario usando Stack (Pila — LIFO).
 * Métodos usados: push, pop, peek, size, print
 */
const { Stack } = require('./dataStructures');

const userStacks = new Map();

function getStack(userId) {
  if (!userStacks.has(userId)) userStacks.set(userId, new Stack());
  return userStacks.get(userId);
}

/** Registra una acción en la pila del usuario (push) */
function recordAction(userId, action) {
  const stack = getStack(userId.toString());
  stack.push({ action, timestamp: new Date().toISOString() });
}

/** Retorna el historial completo (más reciente primero) */
function getHistory(userId) {
  return getStack(userId.toString()).print();
}

/** Retorna la última acción sin eliminarla (peek) */
function getLastAction(userId) {
  return getStack(userId.toString()).peek();
}

/** Retorna y elimina la última acción (pop) */
function popLastAction(userId) {
  return getStack(userId.toString()).pop();
}

/** Retorna el número de acciones registradas (size) */
function getHistorySize(userId) {
  return getStack(userId.toString()).size();
}

module.exports = { recordAction, getHistory, getLastAction, popLastAction, getHistorySize };
