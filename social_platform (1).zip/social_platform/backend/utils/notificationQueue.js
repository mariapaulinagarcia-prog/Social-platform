/**
 * notificationQueue.js
 * Notificaciones pendientes por usuario usando Queue (Cola — FIFO).
 * Métodos usados: enqueue, dequeue, peek, size, print
 */
const { Queue } = require('./dataStructures');

const userQueues = new Map();

function getQueue(userId) {
  if (!userQueues.has(userId)) userQueues.set(userId, new Queue());
  return userQueues.get(userId);
}

/** Encola una notificación (enqueue) */
function pushNotification(userId, notification) {
  getQueue(userId.toString()).enqueue({
    ...notification,
    timestamp: new Date().toISOString(),
    read: false,
  });
}

/** Retorna y vacía todas las notificaciones (dequeue en loop) */
function flushNotifications(userId) {
  const q   = getQueue(userId.toString());
  const all = q.print();
  while (!q.isEmpty()) q.dequeue();
  return all;
}

/** Retorna la primera notificación sin eliminarla (peek) */
function peekNotification(userId) {
  return getQueue(userId.toString()).peek();
}

/** Retorna el número de notificaciones pendientes (size) */
function pendingCount(userId) {
  return getQueue(userId.toString()).size();
}

module.exports = { pushNotification, flushNotifications, peekNotification, pendingCount };
