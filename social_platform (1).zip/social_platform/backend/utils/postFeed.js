/**
 * postFeed.js
 * Feed de publicaciones usando LinkedList (Lista Enlazada).
 * Métodos usados: append/prepend, peek, size, remove, print
 * Estructura: Node (value + next pointer), Head, Tail → null
 */
const { LinkedList } = require('./dataStructures');

const feed = new LinkedList();

/** Agrega un post al inicio del feed (prepend — más reciente primero) */
function addToFeed(post) {
  feed.prepend({
    _id:       post._id?.toString(),
    content:   post.content,
    userName:  post.user?.name || 'Usuario',
    likes:     post.likes?.length || 0,
    comments:  post.comments?.length || 0,
    createdAt: post.createdAt || new Date().toISOString(),
  });
}

/** Elimina un post del feed por su ID (remove) */
function removeFromFeed(postId) {
  feed.remove(p => p._id === postId.toString());
}

/** Busca un post en el feed (peek) */
function findInFeed(postId) {
  return feed.peek(p => p._id === postId.toString());
}

/** Retorna el número de posts en el feed (size) */
function getFeedSize() {
  return feed.size();
}

/** Imprime el feed en consola (print) */
function printFeed() {
  feed.print();
}

/** Retorna el feed como array */
function getFeed() {
  return feed.toArray();
}

/** Carga inicial desde MongoDB */
function loadFeed(posts) {
  [...posts].reverse().forEach(post => addToFeed(post));
}

module.exports = { addToFeed, removeFromFeed, findInFeed, getFeedSize, printFeed, getFeed, loadFeed };
