/**
 * dataStructures.js
 * Implementación de estructuras de datos vistas en clase.
 * Profesor: Jonathan López Londoño — UAO
 *
 * - Queue (Cola)      → FIFO: notificaciones pendientes
 * - Stack (Pila)      → LIFO: historial de acciones del usuario
 * - LinkedList        → feed de publicaciones
 */

// ─────────────────────────────────────────────────────────────────────────────
// COLA (Queue) — FIFO: First In, First Out
// "Always the first element that we add, will be the first that we take out"
// Uso en el proyecto: cola de notificaciones pendientes por usuario
// ─────────────────────────────────────────────────────────────────────────────
class Queue {
  constructor() {
    this.queue = []; // estructura interna basada en array (como visto en clase)
  }

  /** Adds a new element to the queue, placing it at the end of it */
  enqueue(element) {
    this.queue.push(element);
    return this.queue;
  }

  /** Returns the first element of the queue, removing it from the queue */
  dequeue() {
    return this.queue.shift();
  }

  /** Returns the first element of the queue, without removing it */
  peek() {
    return this.queue[0];
  }

  /** Returns the number of elements in the queue */
  size() {
    return this.queue.length;
  }

  /** Prints the contents of the queue */
  print() {
    return this.queue;
  }

  isEmpty() {
    return this.queue.length === 0;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PILA (Stack) — LIFO: Last In, First Out
// "Always the last element that we add, will be the first that we take out"
// Uso en el proyecto: historial de acciones recientes del usuario
// ─────────────────────────────────────────────────────────────────────────────
class Stack {
  constructor() {
    this.stack = []; // implementación con array (como visto en clase)
  }

  /** Adds a new value to the stack, placing it at the top */
  push(element) {
    this.stack.push(element);
    return this.stack;
  }

  /** Returns the last value entered on the stack, popping it off */
  pop() {
    return this.stack.pop();
  }

  /** Returns the last value entered on the stack, without removing it */
  peek() {
    return this.stack[this.stack.length - 1];
  }

  /** Returns the number of elements in the stack */
  size() {
    return this.stack.length;
  }

  /** Prints the contents of the stack */
  print() {
    console.log(this.stack);
    return this.stack;
  }

  isEmpty() {
    return this.stack.length === 0;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// LISTA ENLAZADA (Linked List)
// "They are a structure of linked elements"
// Componentes: Node (dato + apuntador), Head, Tail → null
// Uso en el proyecto: feed de publicaciones (inserción al inicio en O(1))
// ─────────────────────────────────────────────────────────────────────────────

/** Node: Every element in the list — tiene valor y apuntador al siguiente */
class Node {
  constructor(value, next = null) {
    this.value = value;
    this.next  = next;
  }
}

class LinkedList {
  constructor() {
    this.head = null; // Head: first node in the list
    this.tail = null; // Tail: last node, points to null
  }

  /** Adds a new node to the list (al inicio para feeds — más reciente primero) */
  append(node) {
    const newNode = new Node(node);
    if (!this.head) {
      this.head = newNode;
    } else {
      this.tail.next = newNode;
    }
    this.tail = newNode;
  }

  /** Inserta al inicio — O(1) — usado para el feed de publicaciones */
  prepend(node) {
    const newNode = new Node(node);
    newNode.next = this.head;
    this.head    = newNode;
    if (!this.tail) this.tail = newNode;
  }

  /** Returns some node entered on the list (busca por predicado) */
  peek(predicate) {
    if (this.head === null) return false;
    let current = this.head;
    while (current !== null) {
      if (predicate(current.value)) return current.value;
      current = current.next;
    }
    return false;
  }

  /** Returns the number of elements in the list */
  size(current = this.head, acum = 0) {
    if (this.head === null) return 0;
    if (current.next !== null) {
      return this.size(current.next, acum + 1);
    }
    return acum + 1;
  }

  /** Removes a node from the list and joins previous and next node */
  remove(predicate, current = this.head) {
    if (this.head === null) return false;

    if (predicate(this.head.value)) {
      this.head = this.head.next;
      if (!this.head) this.tail = null;
      return true;
    }

    if (current.next !== null) {
      if (predicate(current.next.value)) {
        current.next = current.next.next;
        if (!current.next) this.tail = current;
        return true;
      } else {
        return this.remove(predicate, current.next);
      }
    }
    return false;
  }

  /** Prints the contents of the list */
  print() {
    let node = this.head;
    while (node !== null) {
      console.log(`Valor: ${JSON.stringify(node.value)} | Next: ${node.next?.value ? 'exists' : 'null'}`);
      node = node.next;
    }
  }

  /** Convierte la lista a array para serialización */
  toArray() {
    const result = [];
    let current  = this.head;
    while (current) {
      result.push(current.value);
      current = current.next;
    }
    return result;
  }

  isEmpty() { return this.head === null; }
}

module.exports = { Queue, Stack, LinkedList, Node };
