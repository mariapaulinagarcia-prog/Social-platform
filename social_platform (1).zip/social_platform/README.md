# Plataforma Web Tipo Red Social

## 📌 Descripción
Plataforma web tipo red social con autenticación, publicaciones, amigos y chat en tiempo real.
Desarrollada con Python/Flask (Avance 1) y Node.js + Express + MongoDB + Socket.io (Avance 2).

---

## Avance 1 — Frontend con Flask
- Interfaz completa: Login, Registro, Home, Perfil, Amigos
- Datos servidos desde archivos JSON
- Interactividad con JavaScript vanilla

**Ejecutar:**
```bash
pip install -r requirements.txt
python app.py
# → http://localhost:5000
```

---

## Avance 2 — Backend con Node.js + MongoDB + Socket.io

### 🚀 Tecnologías
- Node.js + Express
- MongoDB + Mongoose
- JWT (autenticación)
- Socket.io (chat en tiempo real)
- bcryptjs (hash de contraseñas)

### 📂 Estructura del Backend
```
backend/
├── server.js               # Punto de entrada
├── .env                    # Variables de entorno
├── package.json
├── models/
│   ├── User.js             # Modelo de usuario
│   └── Post.js             # Modelo de publicación + comentarios
├── controllers/
│   ├── authController.js   # Registro y login
│   ├── userController.js   # Perfil y búsqueda
│   ├── postController.js   # CRUD posts, likes, comentarios
│   └── friendController.js # Gestión de amigos
├── routes/
│   ├── auth.js             # POST /api/auth/register|login
│   ├── users.js            # GET|PUT /api/users/me, GET /api/users/search
│   ├── posts.js            # CRUD /api/posts
│   └── friends.js          # CRUD /api/friends
├── middlewares/
│   ├── auth.js             # Verificación JWT
│   └── errorHandler.js     # Manejo global de errores
├── sockets/
│   └── chat.js             # Chat en tiempo real con Socket.io
└── scripts/
    └── seed.js             # Poblar MongoDB con datos iniciales
```

### ⚙️ Configuración y ejecución

**Requisitos:** Node.js 18+, MongoDB corriendo en localhost:27017

```bash
# 1. Instalar dependencias
cd backend
npm install

# 2. Configurar variables de entorno (editar backend/.env)
MONGO_URI=mongodb://127.0.0.1:27017/red_social
JWT_SECRET=mi_clave_super_secreta_2024
PORT=3000

# 3. (Opcional) Poblar la base de datos con datos de prueba
node scripts/seed.js

# 4. Iniciar el servidor
npm run dev      # con nodemon (desarrollo)
npm start        # producción
# → http://localhost:3000
```

### 🔌 API REST

| Método | Ruta | Descripción | Auth |
|--------|------|-------------|------|
| POST | /api/auth/register | Registrar usuario | ❌ |
| POST | /api/auth/login | Iniciar sesión | ❌ |
| GET | /api/users/me | Ver perfil | ✅ |
| PUT | /api/users/me | Actualizar perfil | ✅ |
| GET | /api/users/search?q= | Buscar usuarios | ✅ |
| GET | /api/posts | Feed de publicaciones | ✅ |
| POST | /api/posts | Crear publicación | ✅ |
| DELETE | /api/posts/:id | Eliminar publicación | ✅ |
| POST | /api/posts/:id/like | Like/Unlike | ✅ |
| POST | /api/posts/:id/comments | Comentar | ✅ |
| GET | /api/friends | Lista de amigos | ✅ |
| POST | /api/friends | Agregar amigo | ✅ |
| DELETE | /api/friends/:id | Eliminar amigo | ✅ |

### 🔌 Eventos Socket.io

| Evento (emit) | Descripción |
|---------------|-------------|
| `join_room` | Unirse a sala de chat privada |
| `send_message` | Enviar mensaje |
| `receive_message` | Recibir mensaje |
| `online_users` | Lista de usuarios conectados |
