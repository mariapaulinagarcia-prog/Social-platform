from flask import Flask, render_template, request, redirect, url_for, session
import json
import os
import requests as http

# 1. Crear la instancia de Flask
app = Flask(__name__)
app.secret_key = 'tu_clave_secreta'

# 2. URL base del backend Node.js
API_URL = 'http://localhost:3000/api'

# 3. Ruta a la carpeta de datos (fallback JSON)
DATA_PATH = os.path.join(os.path.dirname(__file__), 'data')

def load_json(filename):
    filepath = os.path.join(DATA_PATH, filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []

# 4. Ruta principal (Login)
@app.route('/')
def login():
    return render_template('login.html')

# 4.1 Procesar login → MongoDB via API
@app.route('/login', methods=['POST'])
def do_login():
    email = request.form.get('email', '').strip().lower()
    password = request.form.get('password', '').strip()

    try:
        res = http.post(f'{API_URL}/auth/login', json={'email': email, 'password': password}, timeout=5)
        data = res.json()
        if res.status_code == 200:
            session['user_id'] = str(data['user']['id'])
            session['user_name'] = data['user']['name']
            session['user_email'] = data['user']['email']
            session['token'] = data['token']
            return redirect(url_for('home'))
        return render_template('login.html', error=data.get('message', 'Credenciales inválidas.'))
    except Exception:
        # Fallback a JSON local si el backend no está disponible
        users = load_json('users.json')
        user = next((u for u in users if u['email'].lower() == email and u['password'] == password), None)
        if not user:
            return render_template('login.html', error='Correo o contraseña incorrectos.')
        session['user_id'] = user['id']
        session['user_name'] = user['name']
        session['user_email'] = user['email']
        return redirect(url_for('home'))

# 5. Ruta de registro
@app.route('/register')
def register():
    return render_template('register.html')

# 5.1 Procesar registro → MongoDB via API
@app.route('/register', methods=['POST'])
def do_register():
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip().lower()
    password = request.form.get('password', '').strip()
    confirm = request.form.get('confirm_password', '').strip()

    if password != confirm:
        return render_template('register.html', error='Las contraseñas no coinciden.')

    try:
        res = http.post(f'{API_URL}/auth/register', json={'name': name, 'email': email, 'password': password}, timeout=5)
        data = res.json()
        if res.status_code == 201:
            session['user_id'] = str(data['user']['id'])
            session['user_name'] = data['user']['name']
            session['user_email'] = data['user']['email']
            session['token'] = data['token']
            return redirect(url_for('home'))
        return render_template('register.html', error=data.get('message', 'Error al registrar.'))
    except Exception:
        # Fallback a JSON local
        users = load_json('users.json')
        if any(u['email'].lower() == email for u in users):
            return render_template('register.html', error='El correo ya está registrado.')
        new_id = max((u['id'] for u in users), default=0) + 1
        users.append({'id': new_id, 'name': name, 'email': email, 'password': password, 'profile_pic': ''})
        filepath = os.path.join(DATA_PATH, 'users.json')
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(users, f, indent=4, ensure_ascii=False)
        session['user_id'] = new_id
        session['user_name'] = name
        session['user_email'] = email
        return redirect(url_for('home'))

# 6. Ruta de inicio (Home)
@app.route('/home')
def home():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    token = session.get('token', '')

    # Cargar posts desde MongoDB via API
    try:
        res = http.get(f'{API_URL}/posts', headers={'Authorization': f'Bearer {token}'}, timeout=5)
        if res.status_code == 200:
            posts = res.json()
            # Normalizar formato para el template
            for post in posts:
                post['user_name'] = post.get('user', {}).get('name', 'Usuario')
                post['time_ago'] = 'Ahora'
                post['likes'] = len(post.get('likes', []))
                post['comments'] = post.get('comments', [])
        else:
            posts = []
    except Exception:
        # Fallback a JSON local
        posts = load_json('posts.json')
        users = load_json('users.json')
        user_map = {u["id"]: u["name"] for u in users}
        for post in posts:
            post["user_name"] = user_map.get(post["user_id"], "Usuario")
            post["time_ago"] = "Ahora"
            post["likes"] = post.get("likes", 0)

    users = load_json('users.json')
    current_user = {
        'id': session.get('user_id'),
        'name': session.get('user_name', 'Usuario'),
        'email': session.get('user_email', ''),
    }

    return render_template('home.html', posts=posts, users=users, current_user=current_user, token=token)

# 7. Ruta de perfil
@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user = {
        'id': session.get('user_id'),
        'name': session.get('user_name', ''),
        'email': session.get('user_email', ''),
    }
    return render_template('profile.html', user=user)

# 7.1 Ruta para actualizar perfil → MongoDB via API
@app.route('/update_profile', methods=['POST'])
def update_profile():
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip()
    password = request.form.get('password', '').strip()
    token = session.get('token')

    payload = {}
    if name:    payload['name'] = name
    if email:   payload['email'] = email
    if password: payload['password'] = password

    try:
        res = http.put(
            f'{API_URL}/users/me',
            json=payload,
            headers={'Authorization': f'Bearer {token}'},
            timeout=5
        )
        if res.status_code == 200:
            # Actualizar sesión con los nuevos datos
            session['user_name'] = name or session.get('user_name')
            session['user_email'] = email or session.get('user_email')
    except Exception:
        # Fallback: guardar en JSON local
        users = load_json('users.json')
        user_id = session.get('user_id')
        for user in users:
            if str(user['id']) == str(user_id):
                if name:     user['name'] = name
                if email:    user['email'] = email
                if password: user['password'] = password
                break
        filepath = os.path.join(DATA_PATH, 'users.json')
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(users, f, indent=4, ensure_ascii=False)
        session['user_name'] = name or session.get('user_name')
        session['user_email'] = email or session.get('user_email')

    return redirect(url_for('profile'))

# 8. Ruta de amigos → MongoDB via API
@app.route('/friends')
def friends():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    token = session.get('token', '')
    friends_list = []

    try:
        res = http.get(f'{API_URL}/friends', headers={'Authorization': f'Bearer {token}'}, timeout=5)
        if res.status_code == 200:
            friends_list = res.json()
            # Normalizar _id → id para el template
            for f in friends_list:
                f['id'] = f.get('_id', '')
    except Exception:
        # Fallback JSON local
        users = load_json('users.json')
        friends_data = load_json('friends.json')
        current_user_id = session.get('user_id', 1)
        friend_ids = []
        for item in friends_data:
            if item["user_id"] == current_user_id:
                friend_ids = item["friends"]
        friends_list = [u for u in users if u["id"] in friend_ids]

    return render_template('friends.html', friends=friends_list, token=token)

# 9. Ruta para agregar amigo (desde friends)
@app.route('/add_friend', methods=['POST'])
def add_friend():
    friend_id = int(request.form.get('friend_id', 0))
    current_user_id = session.get('user_id', 1)
    friends_data = load_json('friends.json')

    for item in friends_data:
        if item['user_id'] == current_user_id:
            if friend_id not in item['friends']:
                item['friends'].append(friend_id)
            break

    filepath = os.path.join(DATA_PATH, 'friends.json')
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(friends_data, f, indent=4, ensure_ascii=False)

    return redirect(url_for('friends'))

# 10. Ruta para cerrar sesión
@app.route('/logout')
def logout():
    reason = request.args.get('reason', '')
    session.clear()
    if reason == 'inactivity':
        return render_template('login.html', error='Tu sesión cerró por inactividad. Ingresa de nuevo.')
    return redirect(url_for('login'))

# 10. Punto de entrada de la aplicación
if __name__ == '__main__':
    app.run(debug=True)