// =====================================================
// ============== CONVERSIÓN DE TEXTO A EMOJIS =========
// =====================================================
function convertEmojis(text) {
  const emojiMap = {
    // Caras
    ":)": "😊", ":-)": "😊", ":D": "😃", ":-D": "😃",
    ":(": "😢", ":-(": "😢", ":'(": "😭", ":/": "😕",
    ";)": "😉", ";-)": "😉", ":P": "😛", ":-P": "😛",
    ":O": "😮", ":-O": "😮", ":|": "😐", ":*": "😘",
    "XD": "😆", "xD": "😆", "B)": "😎", "B-)": "😎",
    ">:(": "😠", ">:)": "😈", "O:)": "😇", "O:-)": "😇",
    ":'D": "😂", ":3": "😺", "^_^": "😊", "-_-": "😑",
    "o_o": "😳", "O_O": "😳", "T_T": "😭", ">_<": "😣",
    // Corazones
    "<3": "❤️", "</3": "💔", "<33": "💕", "<333": "💖",
    // Gestos
    "+1": "👍", "-1": "👎", ":thumbsup:": "👍", ":thumbsdown:": "👎",
    ":ok:": "👌", ":wave:": "👋", ":clap:": "👏", ":pray:": "🙏",
    ":muscle:": "💪", ":point:": "👉", ":facepalm:": "🤦",
    // Objetos y símbolos
    ":fire:": "🔥", ":star:": "⭐", ":check:": "✅", ":x:": "❌",
    ":100:": "💯", ":tada:": "🎉", ":gift:": "🎁", ":cake:": "🎂",
    ":pizza:": "🍕", ":coffee:": "☕", ":beer:": "🍺",
    ":sun:": "☀️", ":moon:": "🌙", ":rain:": "🌧️", ":snow:": "❄️",
    ":dog:": "🐶", ":cat:": "🐱", ":laugh:": "😂", ":cry:": "😢",
    ":angry:": "😡", ":love:": "😍", ":cool:": "😎", ":think:": "🤔",
    ":shrug:": "🤷", ":eyes:": "👀", ":zzz:": "💤", ":boom:": "💥",
  };
  Object.keys(emojiMap).forEach(key => {
    const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    text = text.replace(new RegExp(escaped, 'g'), emojiMap[key]);
  });
  return text;
}

function escapeHTML(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

// =====================================================
// =================== DAR LIKE ========================
// =====================================================
async function likePost(button) {
  const postCard = button.closest(".post");
  const postId = postCard?.dataset.postId;
  const likeCount = button.querySelector(".like-count");
  const icon = button.querySelector("i");
  const liked = button.dataset.liked === "true";

  // Actualización optimista en UI
  if (liked) {
    likeCount.textContent = parseInt(likeCount.textContent) - 1;
    icon.style.color = "#555";
    button.dataset.liked = "false";
  } else {
    likeCount.textContent = parseInt(likeCount.textContent) + 1;
    icon.style.color = "#a50000";
    button.dataset.liked = "true";
  }

  // Sincronizar con backend si hay postId
  if (postId) {
    try {
      await apiToggleLike(postId);
    } catch (e) {
      console.warn('No se pudo sincronizar el like:', e.message);
    }
  }
}

// =====================================================
// ================== AGREGAR PUBLICACIÓN ==============
// =====================================================
async function addPost() {
  const textarea = document.getElementById("postContent");
  let content = textarea.value.trim();
  if (content === "") {
    alert("Por favor escribe algo antes de publicar.");
    return;
  }
  content = convertEmojis(content);

  try {
    const post = await apiCreatePost(content);
    renderPost(post, true);
    textarea.value = "";
  } catch (err) {
    // Fallback: renderizar localmente si el backend no está disponible
    renderPostLocal(content);
    textarea.value = "";
  }
}

function renderPost(post, prepend = false) {
  const postsContainer = document.getElementById("posts");
  const now = new Date(post.createdAt || Date.now());
  const timeString = `${now.getHours().toString().padStart(2,"0")}:${now.getMinutes().toString().padStart(2,"0")}`;
  const userName = post.user?.name || getUser()?.name || 'Tú';

  const postDiv = document.createElement("div");
  postDiv.className = "card post";
  postDiv.dataset.postId = post._id || '';
  postDiv.innerHTML = `
    <div class="post-header">
      <div class="post-user">
        <div class="post-user-icon"><i class="fas fa-user"></i></div>
        <div class="post-user-info">
          <span class="post-username">${escapeHTML(userName)}</span>
          <span class="post-time">${timeString}</span>
        </div>
      </div>
    </div>
    <div class="post-content"><p>${escapeHTML(post.content)}</p></div>
    <div class="post-actions">
      <button class="action-btn like-btn" onclick="likePost(this)" data-liked="false">
        <i class="fas fa-heart"></i>
        <span class="like-count">${post.likes?.length || 0}</span>
      </button>
      <button class="action-btn comment-btn" onclick="toggleCommentBox(this)">
        <i class="fas fa-comment"></i>
        <span>Comentar</span>
      </button>
      <button class="action-btn delete-btn" onclick="deletePost(this)">
        <i class="fas fa-trash"></i>
      </button>
    </div>
    <div class="comment-section" style="display:none;">
      <div class="comments-list"></div>
      <div class="comment-input-row">
        <input type="text" class="comment-input" placeholder="Escribe un comentario...">
        <button class="btn-comment-send" onclick="addComment(this)">Enviar</button>
      </div>
    </div>
  `;
  if (prepend) postsContainer.prepend(postDiv);
  else postsContainer.appendChild(postDiv);
}

function renderPostLocal(content) {
  const postsContainer = document.getElementById("posts");
  const now = new Date();
  const timeString = `${now.getHours().toString().padStart(2,"0")}:${now.getMinutes().toString().padStart(2,"0")}`;
  const postDiv = document.createElement("div");
  postDiv.className = "card post";
  postDiv.innerHTML = `
    <div class="post-header">
      <div class="post-user">
        <div class="post-user-icon"><i class="fas fa-user"></i></div>
        <div class="post-user-info">
          <span class="post-username">Tú</span>
          <span class="post-time">${timeString}</span>
        </div>
      </div>
    </div>
    <div class="post-content"><p>${escapeHTML(content)}</p></div>
    <div class="post-actions">
      <button class="action-btn like-btn" onclick="likePost(this)" data-liked="false">
        <i class="fas fa-heart"></i><span class="like-count">0</span>
      </button>
      <button class="action-btn comment-btn" onclick="toggleCommentBox(this)">
        <i class="fas fa-comment"></i><span>Comentar</span>
      </button>
      <button class="action-btn delete-btn" onclick="deletePost(this)">
        <i class="fas fa-trash"></i>
      </button>
    </div>
    <div class="comment-section" style="display:none;">
      <div class="comments-list"></div>
      <div class="comment-input-row">
        <input type="text" class="comment-input" placeholder="Escribe un comentario...">
        <button class="btn-comment-send" onclick="addComment(this)">Enviar</button>
      </div>
    </div>
  `;
  postsContainer.prepend(postDiv);
}

// =====================================================
// ================== ELIMINAR PUBLICACIÓN =============
// =====================================================
async function deletePost(button) {
  const post = button.closest(".post");
  const postId = post?.dataset.postId;
  if (!confirm("¿Eliminar esta publicación?")) return;

  if (postId) {
    try {
      await apiDeletePost(postId);
    } catch (e) {
      console.warn('No se pudo eliminar en el servidor:', e.message);
    }
  }
  post.remove();
}

// =====================================================
// ============== MOSTRAR/OCULTAR COMENTARIOS ==========
// =====================================================
function toggleCommentBox(button) {
  const post = button.closest(".post");
  const section = post.querySelector(".comment-section");
  section.style.display = section.style.display === "none" ? "block" : "none";
}

// =====================================================
// ================== AGREGAR COMENTARIO ===============
// =====================================================
async function addComment(button) {
  const row = button.parentElement;
  const input = row.querySelector(".comment-input");
  let text = input.value.trim();
  if (text === "") return;

  const postCard = button.closest(".post");
  const postId = postCard?.dataset.postId;

  if (postId) {
    try {
      await apiAddComment(postId, text);
    } catch (e) {
      console.warn('No se pudo guardar el comentario:', e.message);
    }
  }

  text = convertEmojis(escapeHTML(text));
  const commentsList = row.previousElementSibling;
  const commentDiv = document.createElement("div");
  commentDiv.className = "comment-item";
  commentDiv.innerHTML = `
    <div class="comment-body">
      <div class="comment-user-icon"><i class="fas fa-user"></i></div>
      <div class="comment-content">
        <span class="comment-username">Tú</span>
        <p class="comment-text">${text}</p>
        <div class="comment-actions">
          <button class="action-btn like-btn small" onclick="likePost(this)" data-liked="false">
            <i class="fas fa-heart"></i><span class="like-count">0</span>
          </button>
          <button class="action-btn reply-btn small" onclick="toggleReplyBox(this)">
            <i class="fas fa-reply"></i> Responder
          </button>
        </div>
        <div class="reply-section" style="display:none;">
          <div class="replies-list"></div>
          <div class="comment-input-row">
            <input type="text" class="comment-input" placeholder="Escribe una respuesta...">
            <button class="btn-comment-send" onclick="addReply(this)">Enviar</button>
          </div>
        </div>
      </div>
    </div>
  `;
  commentsList.appendChild(commentDiv);
  input.value = "";
}

// =====================================================
// ============== MOSTRAR/OCULTAR RESPUESTAS ===========
// =====================================================
function toggleReplyBox(button) {
  const commentContent = button.closest(".comment-content");
  const replySection = commentContent.querySelector(".reply-section");
  replySection.style.display = replySection.style.display === "none" ? "block" : "none";
}

// =====================================================
// ================== AGREGAR RESPUESTA ================
// =====================================================
function addReply(button) {
  const row = button.parentElement;
  const input = row.querySelector(".comment-input");
  let text = input.value.trim();
  if (text === "") return;
  text = convertEmojis(escapeHTML(text));

  const repliesList = row.previousElementSibling;
  const replyDiv = document.createElement("div");
  replyDiv.className = "comment-item reply-item";
  replyDiv.innerHTML = `
    <div class="comment-body">
      <div class="comment-user-icon small"><i class="fas fa-user"></i></div>
      <div class="comment-content">
        <span class="comment-username">Tú</span>
        <p class="comment-text">${text}</p>
        <div class="comment-actions">
          <button class="action-btn like-btn small" onclick="likePost(this)" data-liked="false">
            <i class="fas fa-heart"></i><span class="like-count">0</span>
          </button>
        </div>
      </div>
    </div>
  `;
  repliesList.appendChild(replyDiv);
  input.value = "";
}

// =====================================================
// ========= NOTIFICACIONES DE CHAT ================
// =====================================================
// =====================================================
// ========= POPUP EMERGENTE DE MENSAJE ============
// =====================================================
function showChatPopup(from, message) {
  // Eliminar popup anterior si existe
  const existing = document.getElementById("chat-popup");
  if (existing) existing.remove();

  const popup = document.createElement("div");
  popup.id = "chat-popup";
  popup.innerHTML = `
    <div class="chat-popup-avatar"><i class="fas fa-user"></i></div>
    <div class="chat-popup-content">
      <span class="chat-popup-name">${escapeHTML(from.name)}</span>
      <p class="chat-popup-msg">${escapeHTML(message.length > 50 ? message.substring(0, 50) + '...' : message)}</p>
    </div>
    <button class="chat-popup-close" onclick="document.getElementById('chat-popup').remove()">✕</button>
  `;

  // Al hacer clic en el popup abre el chat
  popup.addEventListener('click', (e) => {
    if (e.target.classList.contains('chat-popup-close')) return;
    document.getElementById("chat-popup")?.remove();
    // Expandir el chat si está minimizado
    const chatWindow = document.getElementById("chat-window");
    if (chatWindow && chatWindow.classList.contains("minimized")) {
      toggleChat();
    }
  });

  document.body.appendChild(popup);

  // Auto-cerrar después de 5 segundos
  setTimeout(() => {
    const p = document.getElementById("chat-popup");
    if (p) {
      p.style.animation = "slideOutPopup 0.3s ease forwards";
      setTimeout(() => p.remove(), 300);
    }
  }, 5000);
}

function playNotificationSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(880, ctx.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.15);

    gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);

    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + 0.3);
  } catch (e) {
    // El navegador puede bloquear el audio sin interacción previa
  }
}

let flashInterval = null;
function flashChatHeader() {
  const header = document.querySelector("#chat-window .chat-header");
  if (!header || flashInterval) return;

  let count = 0;
  flashInterval = setInterval(() => {
    header.style.background = count % 2 === 0 ? '#ff6600' : '#a50000';
    count++;
    if (count >= 8) {
      clearInterval(flashInterval);
      flashInterval = null;
      header.style.background = '#a50000';
    }
  }, 300);
}

// =====================================================
// =================== CHAT con Socket.io ==============
// =====================================================
let socket = null;
let activeChatFriendId = null;

function initSocket() {
  const token = getToken();
  if (!token || typeof io === 'undefined') return;

  socket = io('http://localhost:3000', { auth: { token } });

  socket.on('connect', () => console.log('🔌 Socket conectado'));
  socket.on('connect_error', (e) => console.warn('Socket error:', e.message));

  socket.on('receive_message', ({ from, message, timestamp }) => {
    const messages = document.getElementById("chat-messages");
    const chatWindow = document.getElementById("chat-window");

    // Si el chat está abierto y visible, agregar el mensaje normalmente
    if (messages && chatWindow && !chatWindow.classList.contains("minimized")) {
      const msgDiv = document.createElement("div");
      msgDiv.className = "chat-msg received";
      msgDiv.innerHTML = `<span>${escapeHTML(from.name)}: ${escapeHTML(message)}</span>`;
      messages.appendChild(msgDiv);
      messages.scrollTop = messages.scrollHeight;
    } else {
      // Chat cerrado o minimizado → mostrar popup emergente
      showChatPopup(from, message);
      // Si está minimizado, agregar el mensaje igual
      if (messages) {
        const msgDiv = document.createElement("div");
        msgDiv.className = "chat-msg received";
        msgDiv.innerHTML = `<span>${escapeHTML(from.name)}: ${escapeHTML(message)}</span>`;
        messages.appendChild(msgDiv);
        messages.scrollTop = messages.scrollHeight;
      }
    }

    // Notificaciones
    playNotificationSound();
    if (chatWindow && chatWindow.classList.contains("minimized")) {
      flashChatHeader();
    }
    if (document.hidden) {
      const original = document.title;
      let blinkCount = 0;
      const blink = setInterval(() => {
        document.title = blinkCount % 2 === 0 ? '💬 Nuevo mensaje' : original;
        blinkCount++;
        if (blinkCount >= 10) { clearInterval(blink); document.title = original; }
      }, 600);
    }
  });

  socket.on('online_users', (userIds) => {
    // Actualizar indicadores de estado online en la lista de amigos
    document.querySelectorAll('.friend-card').forEach(card => {
      const friendId = card.dataset.friendId;
      const dot = card.querySelector('.online-dot');
      const statusText = card.querySelector('.friend-status');
      if (!dot || !friendId) return;

      if (userIds.includes(friendId)) {
        dot.style.color = '#28a745';
        if (statusText) statusText.innerHTML = `<i class="fas fa-circle online-dot" style="color:#28a745"></i> Conectado`;
      } else {
        dot.style.color = '#ccc';
        if (statusText) statusText.innerHTML = `<i class="fas fa-circle online-dot" style="color:#ccc"></i> Desconectado`;
      }
    });

    // Actualizar indicador en el header del chat abierto
    const chatOnline = document.querySelector('#chat-window .chat-online');
    if (chatOnline && activeChatFriendId) {
      chatOnline.style.color = userIds.includes(activeChatFriendId) ? '#4cff72' : '#ccc';
    }
  });
}

async function openChat(friendName, friendId) {
  const existing = document.getElementById("chat-window");
  if (existing) existing.remove();

  activeChatFriendId = friendId;

  if (socket && friendId) {
    socket.emit('join_room', { friendId });
  }

  const chat = document.createElement("div");
  chat.id = "chat-window";
  chat.innerHTML = `
    <div class="chat-header" onclick="toggleChat()">
      <span><i class="fas fa-circle chat-online"></i> ${escapeHTML(friendName)}</span>
      <div class="chat-header-btns">
        <button onclick="event.stopPropagation(); toggleChat()" class="chat-minimize" title="Minimizar">─</button>
        <button onclick="event.stopPropagation(); document.getElementById('chat-window').remove()" class="chat-close" title="Cerrar">✕</button>
      </div>
    </div>
    <div class="chat-body">
      <div class="chat-messages" id="chat-messages">
        <div class="chat-msg system"><span>Cargando historial...</span></div>
      </div>
      <div class="chat-input-row">
        <button class="chat-emoji-btn" onclick="toggleEmojiHelp()" title="Ver comandos de emojis">😊</button>
        <input type="text" id="chat-input" placeholder="Escribe un mensaje o :fire: :D <3 ..."
               onkeydown="if(event.key==='Enter') sendMessage('${escapeHTML(friendName)}', '${friendId || ''}')">
        <button onclick="sendMessage('${escapeHTML(friendName)}', '${friendId || ''}')">
          <i class="fas fa-paper-plane"></i>
        </button>
      </div>
      <div id="emoji-help" style="display:none;"></div>
    </div>
  `;
  document.body.appendChild(chat);

  // Cargar historial desde MongoDB
  if (friendId) {
    try {
      const messages = await apiGetMessages(friendId);
      const container = document.getElementById("chat-messages");
      container.innerHTML = messages.length === 0
        ? '<div class="chat-msg system"><span>No hay mensajes aún. ¡Saluda! 👋</span></div>'
        : '';

      const currentName = window.CURRENT_USER?.name || 'Tú';
      messages.forEach(msg => {
        const isMine = msg.from.name === currentName;
        const div = document.createElement("div");
        div.className = `chat-msg ${isMine ? 'sent' : 'received'}`;
        div.innerHTML = `<span>${isMine ? '' : escapeHTML(msg.from.name) + ': '}${escapeHTML(msg.message)}</span>`;
        container.appendChild(div);
      });
      container.scrollTop = container.scrollHeight;
    } catch (e) {
      const container = document.getElementById("chat-messages");
      container.innerHTML = '<div class="chat-msg system"><span>¡Hola! 👋</span></div>';
    }
  }
}

function toggleEmojiHelp() {
  const help = document.getElementById("emoji-help");
  if (!help) return;
  if (help.style.display === "none") {
    help.style.display = "flex";
    help.innerHTML = `
      <div class="emoji-help-grid">
        ${[
          [":)","😊"],[":D","😃"],[":(","😢"],["XD","😆"],[";)","😉"],
          [":P","😛"],[":*","😘"],["B)","😎"],[":O","😮"],[":'(","😭"],
          ["<3","❤️"],["</3","💔"],["<33","💕"],["+1","👍"],["-1","👎"],
          [":fire:","🔥"],[":star:","⭐"],[":100:","💯"],[":tada:","🎉"],[":ok:","👌"],
          [":clap:","👏"],[":pray:","🙏"],[":muscle:","💪"],[":think:","🤔"],[":shrug:","🤷"],
          [":eyes:","👀"],[":boom:","💥"],[":zzz:","💤"],[":love:","😍"],[":cool:","😎"]
        ].map(([cmd, emoji]) =>
          `<span class="emoji-chip" onclick="insertEmoji('${cmd}')" title="${cmd}">${emoji}</span>`
        ).join('')}
      </div>
    `;
  } else {
    help.style.display = "none";
  }
}

function insertEmoji(cmd) {
  const input = document.getElementById("chat-input");
  if (input) {
    input.value += cmd + " ";
    input.focus();
  }
}

function toggleChat() {
  const chatWindow = document.getElementById("chat-window");
  if (!chatWindow) return;
  const body = chatWindow.querySelector(".chat-body");
  const isMinimized = chatWindow.classList.toggle("minimized");
  body.style.display = isMinimized ? "none" : "flex";
}

function sendMessage(friendName, friendId) {
  const input = document.getElementById("chat-input");
  let text = input.value.trim();
  if (text === "") return;

  // Convertir comandos de teclado a emojis
  text = convertEmojis(text);

  const messages = document.getElementById("chat-messages");
  const msgDiv = document.createElement("div");
  msgDiv.className = "chat-msg sent";
  msgDiv.innerHTML = `<span>${escapeHTML(text)}</span>`;
  messages.appendChild(msgDiv);
  messages.scrollTop = messages.scrollHeight;
  input.value = "";

  // Enviar por socket si está disponible
  if (socket && friendId) {
    socket.emit('send_message', { friendId, message: text });
  } else {
    // Respuesta simulada como fallback
    setTimeout(() => {
      const reply = document.createElement("div");
      reply.className = "chat-msg received";
      reply.innerHTML = `<span>${escapeHTML(friendName)}: 😊</span>`;
      messages.appendChild(reply);
      messages.scrollTop = messages.scrollHeight;
    }, 1000);
  }
}

// =====================================================
// ================== AMIGOS ===========================
// =====================================================
async function removeFriend(button) {
  if (!confirm("¿Eliminar este amigo?")) return;
  const card = button.closest(".friend-card");
  const friendId = card?.dataset.friendId;

  if (friendId) {
    try {
      await apiRemoveFriend(friendId);
    } catch (e) {
      console.warn('No se pudo eliminar en el servidor:', e.message);
    }
  }
  card.remove();
}

async function addFriend() {
  const input = document.getElementById("search-friend-input");
  const name = input.value.trim();
  if (name === "") return;

  try {
    // Buscar usuario por nombre
    const users = await apiSearchUsers(name);
    if (users.length === 0) {
      alert("No se encontró ningún usuario con ese nombre.");
      return;
    }
    const friend = users[0];
    await apiAddFriend(friend._id);
    renderFriendCard(friend);
    input.value = "";
  } catch (e) {
    alert(e.message || "No se pudo agregar el amigo.");
  }
}

function renderFriendCard(friend) {
  const list = document.getElementById("friends-list");
  const noFriends = list.querySelector('.no-friends');
  if (noFriends) noFriends.remove();

  const card = document.createElement("div");
  card.className = "friend-card";
  card.dataset.friendId = friend._id || '';
  card.innerHTML = `
    <div class="friend-avatar"><i class="fas fa-user"></i></div>
    <div class="friend-info">
      <span class="friend-name">${escapeHTML(friend.name)}</span>
      <span class="friend-status"><i class="fas fa-circle online-dot"></i> Conectado</span>
    </div>
    <div class="friend-actions">
      <button class="btn-chat" onclick="openChat('${escapeHTML(friend.name)}', '${friend._id || ''}')">
        <i class="fas fa-comment"></i> Chat
      </button>
      <button class="btn-remove" onclick="removeFriend(this)">
        <i class="fas fa-user-minus"></i> Eliminar
      </button>
    </div>
  `;
  list.appendChild(card);
}

// =====================================================
// ================== FOTO DE PERFIL ===================
// =====================================================
function previewProfilePic(input) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = function(e) {
      const photo = document.querySelector(".profile-photo");
      photo.innerHTML = `<img src="${e.target.result}" alt="Foto de perfil" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
    };
    reader.readAsDataURL(input.files[0]);
  }
}

// =====================================================
// ================== INIT =============================
// =====================================================
document.addEventListener('DOMContentLoaded', () => {
  initSocket();
});
