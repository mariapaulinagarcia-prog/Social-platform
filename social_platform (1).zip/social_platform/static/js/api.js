/**
 * api.js — Capa de comunicación con el backend Node.js
 * Maneja autenticación JWT, llamadas REST y conexión Socket.io
 */

const API_URL = 'http://localhost:3000/api';

// ── Token helpers ─────────────────────────────────────────────────────────────
const getToken = () => window.AUTH_TOKEN || localStorage.getItem('token');
const setToken = (t) => localStorage.setItem('token', t);
const removeToken = () => localStorage.removeItem('token');

const getUser = () => window.CURRENT_USER || JSON.parse(localStorage.getItem('user') || 'null');
const setUser = (u) => localStorage.setItem('user', JSON.stringify(u));
const removeUser = () => localStorage.removeItem('user');

// ── Fetch con JWT ─────────────────────────────────────────────────────────────
async function apiFetch(path, options = {}) {
  const token = getToken();
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${API_URL}${path}`, { ...options, headers });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Error en la solicitud');
  return data;
}

// ── Auth ──────────────────────────────────────────────────────────────────────
async function apiLogin(email, password) {
  const data = await apiFetch('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  setToken(data.token);
  setUser(data.user);
  return data;
}

async function apiRegister(name, email, password) {
  const data = await apiFetch('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ name, email, password }),
  });
  setToken(data.token);
  setUser(data.user);
  return data;
}

function apiLogout() {
  removeToken();
  removeUser();
  window.location.href = '/';
}

// ── Posts ─────────────────────────────────────────────────────────────────────
const apiGetPosts = () => apiFetch('/posts');
const apiCreatePost = (content) => apiFetch('/posts', { method: 'POST', body: JSON.stringify({ content }) });
const apiDeletePost = (id) => apiFetch(`/posts/${id}`, { method: 'DELETE' });
const apiToggleLike = (id) => apiFetch(`/posts/${id}/like`, { method: 'POST' });
const apiAddComment = (id, text) => apiFetch(`/posts/${id}/comments`, { method: 'POST', body: JSON.stringify({ text }) });

// ── Users ─────────────────────────────────────────────────────────────────────
const apiGetProfile = () => apiFetch('/users/me');
const apiUpdateProfile = (data) => apiFetch('/users/me', { method: 'PUT', body: JSON.stringify(data) });
const apiSearchUsers = (q) => apiFetch(`/users/search?q=${encodeURIComponent(q)}`);

// ── Friends ───────────────────────────────────────────────────────────────────
const apiGetFriends = () => apiFetch('/friends');
const apiAddFriend = (friendId) => apiFetch('/friends', { method: 'POST', body: JSON.stringify({ friendId }) });
const apiRemoveFriend = (friendId) => apiFetch(`/friends/${friendId}`, { method: 'DELETE' });

// ── Messages ──────────────────────────────────────────────────────────────────
const apiGetMessages = (friendId) => apiFetch(`/messages/${friendId}`);
