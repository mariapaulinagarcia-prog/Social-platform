/**
 * inactivity.js — Cierre de sesión automático por inactividad
 * - 4 minutos sin actividad → aviso de 60 segundos
 * - Si no hay respuesta → redirige al login
 * Actividad detectada: mousemove, keydown, click, scroll, touchstart
 */

const INACTIVITY_LIMIT = 4 * 60 * 1000; // 4 min → luego 1 min de aviso = 5 min total
const WARNING_DURATION = 60;             // segundos de cuenta regresiva

let inactivityTimer = null;
let countdownTimer  = null;
let warningSeconds  = WARNING_DURATION;

function resetInactivityTimer() {
  clearTimeout(inactivityTimer);
  // Si el modal ya está visible, cerrarlo y cancelar cuenta regresiva
  const modal = document.getElementById("inactivity-modal");
  if (modal && modal.style.display !== "none") {
    closeInactivityModal();
  }
  inactivityTimer = setTimeout(showInactivityWarning, INACTIVITY_LIMIT);
}

function showInactivityWarning() {
  warningSeconds = WARNING_DURATION;
  const modal = document.getElementById("inactivity-modal");
  if (!modal) return;
  modal.style.display = "flex";
  updateCountdown();
  countdownTimer = setInterval(() => {
    warningSeconds--;
    updateCountdown();
    if (warningSeconds <= 0) {
      clearInterval(countdownTimer);
      logoutByInactivity();
    }
  }, 1000);
}

function updateCountdown() {
  const el = document.getElementById("inactivity-countdown");
  if (el) el.textContent = warningSeconds;
}

function closeInactivityModal() {
  clearInterval(countdownTimer);
  const modal = document.getElementById("inactivity-modal");
  if (modal) modal.style.display = "none";
  resetInactivityTimer();
}

function logoutByInactivity() {
  clearInterval(countdownTimer);
  clearTimeout(inactivityTimer);
  window.location.href = "/logout?reason=inactivity";
}

// Escuchar eventos de actividad
["mousemove", "keydown", "click", "scroll", "touchstart"].forEach(evt => {
  document.addEventListener(evt, resetInactivityTimer, { passive: true });
});

// Iniciar al cargar la página
document.addEventListener("DOMContentLoaded", () => {
  // Inyectar el modal en el DOM
  const modal = document.createElement("div");
  modal.id = "inactivity-modal";
  modal.style.display = "none";
  modal.innerHTML = `
    <div class="inactivity-box">
      <div class="inactivity-icon"><i class="fas fa-clock"></i></div>
      <h3>¿Sigues ahí?</h3>
      <p>Tu sesión cerrará por inactividad en</p>
      <div class="inactivity-countdown" id="inactivity-countdown">${WARNING_DURATION}</div>
      <p class="inactivity-sub">segundos</p>
      <div class="inactivity-actions">
        <button class="btn-primary" onclick="closeInactivityModal()">
          <i class="fas fa-check"></i> Seguir conectado
        </button>
        <button class="btn-logout-now" onclick="logoutByInactivity()">
          <i class="fas fa-sign-out-alt"></i> Cerrar sesión
        </button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  resetInactivityTimer();
});
